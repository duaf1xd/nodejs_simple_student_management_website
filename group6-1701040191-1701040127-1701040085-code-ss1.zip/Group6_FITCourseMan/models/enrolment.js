/*
Authors:
    -Nguyen Duy Thai Son
*/


const mongoose = require('mongoose');

const Student = mongoose.model('Student');
const Course = mongoose.model('Course');

let enrolmentSchema = new mongoose.Schema({
   
        student: {
            type: Number, 
            min: 1000000000, 
            max: 9999999999, 
            required: [true, "missing studentID"],
            validate:{
                isAsync: true,
                validator: function(v, cb){
                    Student.find({studentID: v}, function(err,docs){
                        cb(docs.length != 0);
                    })
                },
                message: 'Student does not exist...'
            }

        },
        course: {
            type: String, 
            minlength: 3, 
            maxlength: 3, 
            required: [true, "missing courseID"],
            validate:{
                isAsync: true,
                validator: function(v, cb){
                    Course.find({courseID: v}, function(err,docs){
                        cb(docs.length != 0);
                    })
                },
                message: 'Course does not exist...'
            }

        },
        semester:{
        	type: Number, 
        	validate:
            {
    		    validator: function(v){
    			    return Number.isInteger(v) && v>= 1 && v<= 8;
    		    },
    		message: "semester must be an integral value from [1 to 8]"
    	    }
        },
        finalGrade: {
        	type: String,
        	enum: ['E', 'G', 'P', 'F', '']
        },
        
        numericGrade:{
            type: Number,
            default: function()
            {
                console.log(escape("This is finalGrade:" +this.finalGrade)); //debugging
                if(this.finalGrade==='E'){
                    return 5;
                }
                else if(this.finalGrade==='G'){
                    return 4;
                }
                else if(this.finalGrade==='P'){
                    return 3;
                }
                else if(this.finalGrade==='F'){
                    return 2;
                }
                else if(this.finalGrade===''){
                    return 1;
                }
                else return 164;
            }
        }

})
mongoose.model('Enrolment', enrolmentSchema);
