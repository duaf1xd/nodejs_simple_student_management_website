/*
Authors:
    -Nguyen Duy Thai Son
*/


const express = require('express');
const mongoose = require('mongoose')
var router = express.Router();
const ObjectId = new  require('mongodb').ObjectId;

const Student = mongoose.model('Student');
const Course = mongoose.model('Course');
const Enrolment = mongoose.model('Enrolment');

router.get('/',(req,res)=>{
    res.render('report/reportHomepage',{
        style: 'report_homepage.css'
    })
         
})

router.get('/my_enrolments',(req,res)=>{
    res.render('report/reportMyEnrolments',{
        style: 'report.css'
    })
         
})

router.post('/showMyEnrolments', (req,res) =>{
    console.log(req.body);
    Enrolment.find({student: req.body.student}, function (err, docs){
    	if (!err) {
            if(!docs.length){
                statusHeader= "No records found, empty table returned!";
            }
            else if(docs.length){
                statusHeader= "Found "+ docs.length+ " record(s) for student with studentID "+ req.body.student;
            }
        	res.render('report/reportShowMyEnrolments', {
            	enrolment: docs,
            	style: 'report.css',
                status: statusHeader
        	});
    	}
        else {
            console.log('Error in retrieving enrolment list of the student...:' + err);
        }
    });        
}) 

router.get('/my_students',(req,res)=>{
    res.render('report/reportMyStudents',{
        style: 'report.css'
    })
         
})


router.post('/showMyCourses', (req,res) =>
{

    console.log(req.body);
    Enrolment.find({course: req.body.course.toUpperCase()}, function (err, docs){
        if (!err) 
        {
            if(!docs.length)
            {
                statusHeader= "No records found, empty table returned!";
            }
            else if(docs.length)
            {
                statusHeader= "Found "+ docs.length+ " record(s) for course with courseID "+ req.body.course.toUpperCase();
            }
            res.render('report/reportShowMyStudents', 
            {
                enrolment: docs,
                style: 'report.css',
                status: statusHeader
            });
        }
        else 
        {
            console.log('Error in retrieving student list of the course...:' + err);
        }     
    })
}) 

router.get('/failed_students',(req,res)=>
{
    Enrolment.find({finalGrade: 'F'}, function(err, docs)
    {
        if (!err) 
        {
            if(!docs.length)
            {
                statusHeader= "There are no student with a fail grade, empty table returned";
            }
            else if(docs.length)
            {
                statusHeader= "Found "+ docs.length+ " records";
            }
            res.render('report/reportShowMyStudents', 
            {
                enrolment: docs,
                style: 'report.css',
                status: statusHeader
            });
        }
        else console.log('Error in retrieving list of failed students...:' + err);
    })    
})
module.exports = router

