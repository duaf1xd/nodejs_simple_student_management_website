/*
Authors:
    -Do Thi Nhung: GET/POST routers and basic functions
    -Nguyen Duy Thai Son: rearrange routers, improve functions and validate
*/

const express = require('express');
const mongoose = require('mongoose')
var router = express.Router();
const ObjectId = new  require('mongodb').ObjectId;

const Course = mongoose.model('Course');
const Enrolment = mongoose.model('Enrolment');



router.get('/',(req,res)=>{
    Course.find((err, docs) => {
    if (!err) {
        res.render('course/showCourse', {
            course: docs,
            style: 'course.css',
            status: req.query.status
        });
    }
        else {
            console.log('Error in retrieving course list :' + err);
        }
    });        
})

router.get('/add',(req,res)=>{
        res.render('course/addCourse',{
        style: 'course.css'
    })
         
})
 
router.post('/add',(req,res)=>{
    insertCourseRecord(req,res)
})

function insertCourseRecord(req,res){
    var course = new Course();
    course.courseID = req.body.courseID.toUpperCase();
    course.courseName = req.body.courseName;
    course.prerequisites= req.body.prerequisites.toUpperCase();
    if(req.body.prerequisites.toUpperCase().length){
        Course.find({courseID: req.body.prerequisites.toUpperCase()}).exec(function(err, c_docs){
            if(err){
                res.redirect('/course/operation_failed?err='+ err.message);
            }
            else if(req.body.courseID.toUpperCase() === req.body.prerequisites.toUpperCase()){ //self-prereq
                res.redirect('/course/operation_failed?err=prerequisites:%20not%20a%20valid%20prerequisite%20'
                    +'(a%20course%20cannot%20have%20itself%20as%20prerequisite)');
            }
            else if(!c_docs.length){ //prereq not found
                res.redirect('/course/operation_failed?err=prerequisites:%20not%20a%20valid%20prerequisite%20'
                    +'(does%20not%20exist%20such%20course%20in%20DB)');
            }
            else{ //prereq is found
                course.save((error,doc)=>{
                if(error) {
                    res.redirect('/course/operation_failed?err='+ error.message);
                }
                else res.redirect('/course?status=Add%20course%20with%20ID%20'
                    + req.body.courseID.toUpperCase() + '%20succeeded.');
       
                })
            }
        })
    }
    else{
        course.save((err,doc)=>{
        if(err) {
            res.redirect('/course/operation_failed?err='+ err.message)
        }
        else res.redirect('/course?status=Add%20course%20with%20ID%20'
            + req.body.courseID.toUpperCase() + '%20succeeded.');
        })
    }
}

router.get('/operation_failed',(req,res)=>{
        res.render('course/modifyCourseFailed',
        {
            errorMessage: req.query.err, 
            style: 'course.css'
        }
    )       
})

router.get('/deleteCourse/:id', (req, res) => 
{

    let reso= Course.find({_id: req.params.id});
    reso.exec(function(err, c_docs){
        value= c_docs[0].courseID;
        if(err){
            console.log(err);
        }
        else
        {
            Enrolment.find({course: value}).exec(function(er, e_docs)
            {
                if(er) console.log(er);
                else if(e_docs.length)
                {
                    //console.log(e_docs)
                    res.redirect('/course?status=Delete%20course%20with%20ID%20'
                        + value
                        + '%20failed%20because%20course%20has'
                        + '%20reference%20in%20Enrolment%20table%20(preventing%20DB%20collapse)');
                }
                else
                {
                    Course.find({prerequisites: value}).exec(function(error, temp)
                    {
                        if(error) console.log(error);
                        else if(temp.length)
                        {
                            res.redirect('/course?status=Delete%20course%20with%20ID%20'
                            + value
                            + '%20failed%20because%20course%20is'
                            + '%20prerequisite%20of%20another%20course%20(preventing%20DB%20collapse)');
                        }
                        else
                        {
                            console.log("No matching record found, can delete")
                            Course.findByIdAndRemove(req.params.id, (err4, doc) => {
                                if (!err4) 
                                {   
                                    res.redirect('/course?status=Delete%20course%20with%20ID%20'
                                        +value +'%20succeeded.');
                                }
                                else
                                {
                                    res.redirect('/course/operation_failed?err='+ err4.message);
                                }
                            })                           
                        }
                    })
                }
            })
        }
    });

    // Course.findByIdAndRemove(req.params.id, (err, doc) => {
    //     if (!err) {   
    //         res.redirect('/course');
    //     }
    //     else { console.log('Error in course delete :' + err); }
    // });
});

router.get('/updateCourse/:id', (req,res)=>{
    let id = req.params.id
    let update = Course.findById(ObjectId(id));
    update.exec(function(err,data){
        if(err) throw err;
        res.render('course/updateCourse',{
            course: data,
            style: 'course.css'
        })
    })
})

router.post('/update/', function updateCourseRecord(req,res){
    
    var update = Course.findByIdAndUpdate(req.body._id,
    {
        courseName : req.body.courseName,
        prerequisites: req.body.prerequisites.toUpperCase()
    }, {new: true, runValidators: true})

    if(req.body.prerequisites.toUpperCase().length){
        Course.find({courseID: req.body.prerequisites.toUpperCase()}).exec(function(err, c_docs){
            
            if(err){
                res.redirect('/course/operation_failed?err='+ err.message);
            }

            else if(!c_docs.length){ //throwing 'ERR_HTTP_HEADERS_SENT' //if prerequisite does not exist
                //console.log("This is if else if block")
                res.redirect('/course/operation_failed?err=prerequisites:%20not%20a%20valid%20prerequisites%20'
                    +'(does%20not%20exist%20such%20course%20in%20DB)' );
            }
            else{ //if prerequisite is found
                Course.find({_id: req.body._id}).exec(function(er, temp){
                    console.log("Currently editing ID: "+ temp[0].courseID);
                    console.log("prerequisite: "+ c_docs[0]);
                    console.log("With:"+ req.body.prerequisites.toUpperCase());                    
                    if(er){
                        throw er;
                    }
                    else if(temp[0].courseID === req.body.prerequisites.toUpperCase()){
                        console.log("Caught self-prerequisiting")
                        res.redirect('/course/operation_failed?err=prerequisites:%20not%20a%20valid%20prerequisite%20'
                            +'(a%20course%20cannot%20have%20itself%20as%20prerequisite)');
                    }
                    else if(temp[0].courseID === c_docs[0].prerequisites){
                        console.log("Caught interlockings")
                        res.redirect('/course/operation_failed?err=prerequisites:%20not%20a%20valid%20prerequisite%20'
                            +'(two%20courses%20cannot%20have%20each%20other%20as%20prerequisite)');
                    }
                    else{
                        update.exec(function(error,data){
                            if(error){
                                //console.log("In course update failed by: "+ err.message);
                                res.redirect('/course/operation_failed?err='+ err.message);
                            }
                            else {
                                //console.log("if else else ran");
                                res.redirect('/course?status=Update%20course%20'
                                + req.body.courseName+ '%20succeeded.');
                            }
                        })                    
                    }
                }) 
            }
        })
    }
    else
    {
        update.exec(function(err,data){
        if(err){
            console.log("In course update failed by: "+ err.message);
            res.redirect('/course/operation_failed?err='+ err.message);
        }
        else res.redirect('/course?status=Update%20course%20'
            + req.body.courseName+ '%20succeeded.');
        })
    }
}) 

module.exports= router