/*
Authors:
    -Do Thi Nhung: most parts
    -Nguyen Duy Thai Son: some minor changes to rearrange routers
*/


require('./models/data')
const express = require('express')
const bodyParser = require('body-parser');
const studentController = require('./routers/studentController')
const courseController = require('./routers/courseController')
const enrolmentController = require('./routers/enrolmentController')
const reportController = require('./routers/reportController')

const exphbs = require('express-handlebars');
const path = require('path');

let app = express();
app.use(express.static('public'))
app.use(bodyParser.urlencoded({
    extended:true
}))
app.use(bodyParser.json())
app.get('/homepage',(req,res)=>{
    res.render('homepage',{
        style:'homepage.css'
    })
})
app.set('views',path.join(__dirname,'/views/'))
app.engine('handlebars',exphbs({defaultLayout:'mainLayout'}))
app.set('view engine','handlebars')
app.listen(3030,()=>{
    console.log('express server is started at 3030')
})


app.get('/',(req,res)=>{
    res.redirect('/homepage');
})


app.use('/student', studentController);
app.use('/course', courseController);
app.use('/enrolment', enrolmentController);
app.use('/report', reportController);
