/*
Authors:
    -Nguyen Duy Thai Son
*/


const express = require('express');
const mongoose = require('mongoose')
var router = express.Router();
const ObjectId = new  require('mongodb').ObjectId;

const Enrolment = mongoose.model('Enrolment');


router.get('/',(req,res)=>{
    Enrolment.find((err, docs) => {
    if (!err) {
        res.render('enrolment/showEnrolment', {
            enrolment: docs,
            style: 'enrolment.css',
            status: req.query.status
        });
    }
        else {
            console.log('Error in retrieving enrolment list :' + err);
        }
    });        
})

router.get('/add',(req,res)=>{
        res.render('enrolment/addEnrolment',{
        style: 'enrolment.css'
    })
         
})
 
router.post('/add',(req,res)=>{
    insertEnrolmentRecord(req,res)
})

function insertEnrolmentRecord(req,res){
    
    const { student, course, semester, finalGrade } = req.body;

    let enrolment = new Enrolment({ student, course, semester, finalGrade });

    console.log(enrolment.numericGrade);
    enrolment.save((err,doc)=>{
        if(err) {
            console.log("In enrolment add failed by: "+ err.message);
            res.redirect('/enrolment/operation_failed?err='+ err.message);
        }
        else res.redirect('/enrolment?status=Add%20Enrolment%20between%20Student%20'
            +req.body.student
            +'%20and%20Course%20'+ req.body.course+ '%20succeeded');
       
   })
}

router.get('/operation_failed',(req,res)=>{
        console.log(req.query);
        res.render('enrolment/modifyEnrolmentFailed', 
            {
                errorMessage: req.query.err,
                style: 'enrolment.css'
            });
})

router.get('/deleteEnrolment/:id', (req, res) => {

    Enrolment.findByIdAndRemove(req.params.id, (err, doc) => {
        if (!err) {   
            res.redirect('/enrolment?status=Delete%20Enrolment%20successfully');
        }
        else { console.log('Error in Enrolment delete :' + err); }
    });
});

router.get('/updateEnrolment/:id', (req,res)=>{
    let id = req.params.id
    let update = Enrolment.findById(ObjectId(id));
    update.exec(function(err,data){
        if(err){
            console.log(err);
        }
        res.render('enrolment/updateEnrolment',{
            enrolment: data,
            style: 'enrolment.css'
        })
    })
})

router.post('/update', function updateEnrolmentRecord(req,res){

    let num= 166;
    if(req.body.finalGrade==='E'){
        num= 5;
    }
    else if(req.body.finalGrade==='G'){
        num= 4;
    }
    else if(req.body.finalGrade==='P'){
        num= 3;
    }
    else if(req.body.finalGrade==='F'){
        num= 2;
    }
    else if(req.body.finalGrade===''){
        num= 1;
    }

    var update = Enrolment.findByIdAndUpdate(req.body._id,
    {finalGrade: req.body.finalGrade, numericGrade: num}, {new: true, runValidators: true})

    update.exec(function(err,data){
        if(err){
            console.log("In enrolment update failed by: "+ err.message);
            res.redirect('/enrolment/operation_failed?err='+ err.message);
        }
        else res.redirect('/enrolment?status=Update%20finalGrade%20for%20Enrolment%20successfully');
    })
}) 

router.get('/sort',(req,res)=>{
    Enrolment.find({}).sort('-numericGrade').exec(function(err, docs) {
        if (!err) {
            res.render('enrolment/sortEnrolment', {
                enrolment: docs,
                style: 'enrolment.css'
            });
        }
        else {
            console.log('Error in retrieving sorted enrolment list :' + err);
        }
    });
})


module.exports = router


/*
    Enrolment.find((err, docs) => {
    if (!err) {
        res.render('enrolment/sortEnrolment', {
            enrolment: docs,
            style: 'enrolment.css'
        });
    }
        else {
            console.log('Error in retrieving enrolment list :' + err);
        }
    });      
*/

/*
var update = Enrolment.findByIdAndUpdate(req.body._id,
    {
        finalGrade: req.body.finalGrade
    })
*/

/*
function insertEnrolmentRecord(req,res){
    var enrolment = new Enrolment();
    enrolment.student = req.body.student;
    enrolment.course = req.body.course;
    enrolment.semester= req.body.semester;
    enrolment.finalGrade= req.body.finalGrade;
    console.log("req.body.finalGrade is: "+ escape(req.body.finalGrade));
    enrolment.save((err,doc)=>{
        if(err) {
            console.log(err);
            res.redirect('/enrolment/operation_failed')
        }
        else res.redirect('/enrolment');
       
   })
}
*/