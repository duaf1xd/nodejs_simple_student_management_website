/*
Authors:
    -Do Thi Nhung: GET/POST routers and basic functions
    -Nguyen Duy Thai Son: rearrange routers, improve functions and validate
*/


const express = require('express');
const mongoose = require('mongoose')
var router = express.Router();
const ObjectId = new  require('mongodb').ObjectId;

const Student = mongoose.model('Student');
const Enrolment = mongoose.model('Enrolment');
 

//get show page
router.get('/',(req,res)=>{
    //console.log("This is passed back req.query:"+ req.query.status);
    Student.find((err, docs) => {
    if (!err) {
        res.render('student/showStudent', {
            student: docs,
            style: 'student.css',
            status: req.query.status
        });
    }
        else {
            console.log('Error in retrieving student list :' + err);
        }
    });

         
})
 
//get add page
router.get('/add',(req,res)=>{
           res.render('student/addStudent',{
           style: 'student.css'
    })
         
})
 
// post the information in the update page
router.post('/add',(req,res)=>{
    insertStudentRecord(req,res)
   
})
     
function insertStudentRecord(req,res){
    var student = new Student();
    student.studentID = req.body.studentID;
    student.firstName = req.body.firstName;
    student.lastName= req.body.lastName;
    student.address = req.body.address;
    student.dateOfBirth = reformatDate(req.body.dateOfBirth);
    student.save((err,doc)=>{
        if(err) {
            //console.log(err);
            res.redirect('/student/operation_failed?err='+ err.message)
        }
        else res.redirect('/student?status=Add%20student%20with%20ID%20'
            + req.body.studentID+ '%20succeeded.');
       
   })
}

/*
before reformat
1999-12-02 (YYYY-MM-DD)

0123456789

1996-02-29

after reformat
02/12/1999(DD/MM/YYYY)
*/

function reformatDate(date){
    result= date.charAt(8)+ date.charAt(9)+ '/'+ date.charAt(5) 
        + date.charAt(6)+ '/'+ date.charAt(0)+ date.charAt(1)+ date.charAt(2)+ date.charAt(3);
    return result;
}

/* unused
function revertDate(date){
    result= date.charAt(6)+ date.charAt(7)+ date.charAt(8) 
        + date.charAt(9)+ '-'+ date.charAt(3)+ date.charAt(4)+ '-'+ date.charAt(0)+ date.charAt(1);
    return result;
}
*/


// get the information of student
router.post('/update/', function updateStudentRecord(req,res){
    //console.log("Find studentID "+ req.body.studentID); 
    //doesn't send req.body.studentID if disabled
    var update = Student.findByIdAndUpdate(req.body._id,{
        firstName : req.body.firstName,
        lastName: req.body.lastName,
        address : req.body.address,
        dateOfBirth : reformatDate(req.body.dateOfBirth)
    }, {new: true, runValidators: true})

    update.exec(function(err,data){
        if(err){
            console.log("In student update failed by: "+ err.message);
            res.redirect('/student/operation_failed?err='+ err.message);
        }
        else res.redirect('/student?status=Update%20student%20with'
            +'%20full%20name%20'+ req.body.firstName+ '%20'
            +req.body.lastName + '%20succeeded.');
    })
}) 

router.get('/updateStudent/:id', (req,res)=>{
    let id = req.params.id
    let update = Student.findById(ObjectId(id));
    update.exec(function(err,data){
        if(err)throw err;

        res.render('student/updateStudent',{
            student:data,
            style: 'student.css'
        })
    })
})
 
router.get('/deleteStudent/:id', (req, res) => {


    //console.log("Deleting "+ req.params.id);
    let reso= Student.find({_id: req.params.id});
    reso.exec(function(err, s_docs){
        value= s_docs[0].studentID;
        if(err){
            console.log(err);
        }
        else{
            Enrolment.find({student: value}).exec(function(err, e_docs){
                if(err) console.log(err);
                else if(e_docs.length){
                    //console.log(e_docs)
                    res.redirect('/student?status=Delete%20student%20with%20ID%20'
                        + value
                        + '%20failed%20because%20student%20has'
                        + '%20reference%20in%20Enrolment%20table%20(preventing%20DB%20collapse)')
                }
                else{
                    //console.log("No matching record found, can delete")
                    Student.findByIdAndRemove(req.params.id, (err, doc) => {
                        if (!err) {   
                            res.redirect('/student?status=Delete%20student%20with%20ID%20'
                                +value +'%20succeeded.');
                        }
                        else{
                            res.redirect('/student/operation_failed?err='+ err.message);
                        }
                    });
                }
            })
        }
    });
});

router.get('/operation_failed',(req,res)=>{
    res.render('student/modifyStudentFailed',
        {
           errorMessage: req.query.err, 
           style: 'student.css'
        }
    );
         
})
module.exports =router;


// //filter student
// router.post('/filter',(req,res)=>{

//     var filterstudentID = req.body.filterStudentID;
//     var filterfirstName = req.body.filterFirstName;
//     var filterlastName = req.body.filterLastName;
//     if(filterstudentID!='' && filterfirstName !='' && filterlastName!=''){
//       var filterParameter = {
//          $and:[{studentID:filterstudentID},{$and:[{firstName:filterfirstName},{lastName:filterlastName}]}]
//       }
//     }
//     else if(filterstudentID!='' && filterfirstName=='' && filterlastName ==''){
//         var filterParameter ={
//             $and:[{firstName:filterfirstName},{lastName:filterlastName}]
//         }
//     }
//     var studentFilter = Student.find(filterParameter)

//     studentFilter.exec(function(err,data){
//         if(err)throw err;
//         res.render('student/showStudent',{
//             student:data
            
//         })
//     })
   

// })