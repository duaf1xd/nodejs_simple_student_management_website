/*
Authors:
    -Nguyen Duy Thai Son
*/


const mongoose = require('mongoose');
let uniqueValidator = require('mongoose-unique-validator');


let courseSchema = new mongoose.Schema({
    courseID: {
    	type: String, 
    	minlength: 3, 
    	maxlength: 3, 
    	required: [true, "missing courseID"],
    	unique: true
    }, 
    courseName: {
        type: String, 
        required: [true, "missing courseName"],
        validate:{
            validator: function(v){
                if (v.charAt(0)=== v.charAt(0).toUpperCase()) return true;
                else return false;
            }, 
            message: "courseName is not written properly"
        }
    },
    prerequisites: {
    	type: String,
    	validate:{
    		validator: function(v){
                if (v.length === 0 || v.length === 3) return true;
                else return false;
    		}, 
    		message: "prerequisites must either be empty or (have length= 3 and exist)"
    	}
    }
})


mongoose.model('Course', courseSchema);
courseSchema.plugin(uniqueValidator);

//minlength: 3, maxlength: 3,

/*
const Course = mongoose.model('Course');
validator: function(v, cb){
                if (v.length === 0) {
                    return true;
                }

                if (v.length === 3) {
                    const pre = Course.findOne({courseID: v});

                    return pre != null;
                }

                return false;
            }, 
*/