/*
Authors:
    -Do Thi Nhung
    -Nguyen Duy Thai Son
*/


const mongoose = require('mongoose');
let uniqueValidator = require('mongoose-unique-validator');

const Schema = mongoose.Schema
var studentSchema = new Schema({
    
    studentID: {
    	type: Number, 
    	min: 1000000000, 
    	max: 9999999999, 
    	required: [true, "missing studentID"],
    	unique: true // this is problematic
    	},
    firstName: {
        type: String, 
        required: [true, "missing firstName"],
        validate:{
            validator: function(v){
                if (v.charAt(0)=== v.charAt(0).toUpperCase()){
                    for(i=0; i<v.length; ++i){
                        if (v.charAt(i) >= '0' && v.charAt(i) <= '9') {
                            return false;
                        }
                    }
                    return true;
                }
                else return false;
            }, 
            message: "firstName is not written properly"
        }
    },
    lastName: {
        type: String, 
        required: [true, "missing lastName"],
        validate:{
            validator: function(v){
                if (v.charAt(0)=== v.charAt(0).toUpperCase()){
                    for(i=0; i<v.length; ++i){
                        if (v.charAt(i) >= '0' && v.charAt(i) <= '9') {
                            return false;
                        }
                    }
                    return true;
                }
                else return false;
            }, 
            message: "lastName is not written properly"
        }
    },
    address: {type: String, required: [true, "missing address"]},
    dateOfBirth: {
        type: String, 
        required: [true, "missing dateOfBirth"],
        validate:{
            validator: function(v){
                return v.length>=9;
            }, 
            message: "missing dateOfBirth"
        }
    }
})

mongoose.model('Student', studentSchema);
studentSchema.plugin(uniqueValidator);